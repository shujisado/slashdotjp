package Slash::Clout::Moderate;

use vars qw($VERSION);

($VERSION) = ' $Revision: 1.3 $ ' =~ /\$Revision:\s+([^\s]+)/;

sub getUserClout {
	my($class, $user_stub) = @_;
	return 1;
}

1;

