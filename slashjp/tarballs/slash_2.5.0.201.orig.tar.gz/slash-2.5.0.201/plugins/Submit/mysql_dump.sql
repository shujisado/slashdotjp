#
# $Id: mysql_dump.sql,v 1.1 2006/01/12 01:35:46 jamiemccarthy Exp $
#

INSERT INTO vars (name, value, description) VALUES ('submissions_link_relnofollow', '0', 'Add a rel="nofollow" to the submitter\'s vanity link for all submissions?');

