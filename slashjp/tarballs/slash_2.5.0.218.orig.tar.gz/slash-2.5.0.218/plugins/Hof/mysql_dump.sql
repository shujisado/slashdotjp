INSERT INTO vars (name, value, description) VALUES ('hof_do_not_count', '', 'Do not list stories with these (space-separated) sids in hof.pl');
