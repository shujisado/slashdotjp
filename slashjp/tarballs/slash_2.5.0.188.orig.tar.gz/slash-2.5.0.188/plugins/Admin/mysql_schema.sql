DROP TABLE IF EXISTS uncommonstorywords;
CREATE TABLE uncommonstorywords (
	word VARCHAR(255) NOT NULL,
	PRIMARY KEY (word)
) TYPE=InnoDB;

