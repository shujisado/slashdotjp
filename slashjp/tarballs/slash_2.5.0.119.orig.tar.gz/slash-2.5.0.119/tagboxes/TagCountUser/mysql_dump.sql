# $Id: mysql_dump.sql,v 1.2 2006/05/30 18:37:54 jamiemccarthy Exp $
INSERT INTO tagboxes (tbid, name, affected_type, weight, last_run_completed, last_tagid_logged, last_tdid_logged, last_tuid_logged) VALUES (NULL, 'TagCountUser', 'user', 1, '2000-01-01 00:00:00', 0, 0, 0);
#INSERT INTO tagbox_userkeyregexes VALUES ('TagCountUser', '^tag_clout$');
