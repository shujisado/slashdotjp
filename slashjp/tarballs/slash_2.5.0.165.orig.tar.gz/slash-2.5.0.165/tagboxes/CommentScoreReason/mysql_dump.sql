# $Id: mysql_dump.sql,v 1.1 2006/11/20 22:01:40 jamiemccarthy Exp $
INSERT INTO tagboxes (tbid, name, affected_type, weight, last_run_completed, last_tagid_logged, last_tdid_logged, last_tuid_logged) VALUES (NULL, 'CommentScoreReason', 'globj', 1, '2000-01-01 00:00:00', 0, 0, 0);
#INSERT INTO tagbox_userkeyregexes VALUES ('CommentScoreReason', '^tag_clout$');

